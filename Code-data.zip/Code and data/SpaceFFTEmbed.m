% function result=fft28LineFDEm(filename,pathname,watername)
[filename pathname]=uigetfile('*.shp','ѡ��ԭʼshape�ļ�Line');
watername='D:\shpdata\wm6432.bmp';
watername2='D:\shpdata\wm64322.bmp';
w=imread(watername);
w=logisticE(w,0.98);
[wm wn]=size(w);
w=reshape(w,1,wm*wn);

w2=imread(watername2);
w2=logisticE(w2,0.98);
w2=reshape(w2,1,wm*wn);
s=shaperead([pathname filename ]);
R=20;% FFT ����ֵ

ss=s;
just=1e-3;



t=size(w);
M=t(2);
num=size(s);
num1=num(1);
h= waitbar(0,'�������У������ĵȴ�������');
myRoot = [pathname '\SpaceFftFDXW\'];
if ~isdir(myRoot) %�ж�·���Ƿ����
    mkdir(myRoot);
end
pathname=myRoot;
allPointNum=0;
p00=0;
p11=0;
p22=0;
p33=0;
maxError=0;
RMSE=0;
fidwc = fopen([pathname filename '_wc.txt'], 'w');

for k=1:num1
    px=s(k).X;
    py=s(k).Y;
    n1=size(px);
    npoint=n1(2)-1;
    allPointNum=allPointNum+npoint;
    
    pxx=px(1:npoint);
    pyy=py(1:npoint);
    pxx1=px(1:npoint);
    pyy1=py(1:npoint);
    
    %     ��ʼ����
    r=100;%��������ֵ
    sctrl=1e5*just;
    for j=1:npoint
        dx=floor(pxx(j));
        if isnan(dx)
            continue;
        end
        dy=floor(pyy(j));
        indexX=mod(dx,M)+1;
        indexY=mod(dy,M)+1;
        fx=pxx(j)*sctrl;
        fy=pyy(j)*sctrl;
        if w2(indexX)==0 && mod(fx,r)>=r/2           
            pxx(j)=(fx-r/2)/sctrl;
        elseif w2(indexX)==1 && mod(fx,r)<r/2
            pxx(j)=(fx+r/2)/sctrl;
        end
        if w2(indexY)==0 && mod(fy,r)>=r/2            
            pyy(j)=(fy-r/2)/sctrl;
        elseif w2(indexY)==1 && mod(fy,r)<r/2
            pyy(j)=(fy+r/2)/sctrl;
        end
    end
    
    %    �������    
    
    %    FFT��ʼ
    fctrl=1e8*just;
    z=pxx+pyy*1i;
    y=fft(z);
    fd=abs(y);
    xw=angle(y);
    fd=fd*fctrl;
    xw=xw*fctrl;
    p=mod(floor(fd(2)/100),M)+1;
    if isnan(p)
        continue
    end
    pxw=mod(floor(xw(2)/100),M)+1;
    for  n=2:npoint
        if w(p)==0 &&  mod(fd(n),R)>R/2
            fd(n)=fd(n)-R/2;
        elseif w(p)==1 && mod(fd(n),R)<R/2
            fd(n)=fd(n)+R/2;
        end
        if w(pxw)==0  && mod(xw(n),R)>R/2
            xw(n)=xw(n)-R/2;
        elseif w(pxw)==1  &&  mod(xw(n),R)<R/2
            xw(n)=xw(n)+R/2;
        end
        p=p+1;
        pxw=pxw+1;
        if p==M+1
            p=1;
        end
        if pxw==M+1
            pxw=1;
        end
    end
    fd=fd/fctrl;
    xw=xw/fctrl;
    xy=fd.*cos(xw)+fd.*sin(xw)*1i;
    zz=ifft(xy);
    sb=real(zz);
    xb=imag(zz);
    pxx(1:npoint)=sb;
    pyy(1:npoint)=xb;

    %    FFT����
    px(1:npoint)=pxx;
    py(1:npoint)=pyy;
    s(k).X=px;
    s(k).Y=py;
    %     ���ͳ��
    for j=1:npoint
        wc1=pxx(j)-pxx1(j);
        wc2=pyy(j)-pyy1(j);
        wc=wc1*wc1+wc2*wc2;
        RMSE=RMSE+wc;
        wc=sqrt(wc);
        fprintf(fidwc,'%.16f\r\n',wc);
        if wc<0.0000000000001
            p00=p00+1;
        elseif wc<1
            p11=p11+1;
        elseif wc<2
            p22=p22+1;
        else
            p33=p33+1;
        end
        
        if wc>maxError
            maxError=wc;
        end
    end
    % ���ͳ�ƽ���
    
    waitbar(k/num1);
end
fclose(fidwc);
shapewrite(s,[pathname filename ]);
fid = fopen([pathname filename '_result.txt'], 'w');
fprintf(fid,'%s\r\n',filename);
fprintf(fid,'allPointNum=%f\r\n',allPointNum);
fprintf(fid,'maxError=%.16f\r\n',maxError);
fprintf(fid,'RMSE=%.16f\r\n',sqrt(RMSE/allPointNum));
fprintf(fid,'p00=%f\r\n',p00);
fprintf(fid,'p11=%f\r\n',p11);
fprintf(fid,'p22=%f\r\n',p22);
fprintf(fid,'p33=%f\r\n',p33);
fclose(fid);
close(h);
msgbox('���');
