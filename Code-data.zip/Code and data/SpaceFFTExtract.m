% function result=fft28LineFDEx(filename,pathname,watername)
[filen pathname]=uigetfile('*.shp','ѡ��ˮӡshape�ļ�Line','MultiSelect','on');
if iscell(filen)    
    imNum=size(filen);
    imNum=imNum(2);
else    
    imNum=1;
end
just=1e-3;
for no=1:imNum
    if imNum==1
        filename=filen;
    else
        filename=filen{no};
    end
    watername='D:\shpdata\wm6432.bmp';
    R=20;
    s=shaperead([pathname filename ]);
    [w cmap]=imread(watername);
    [wm wn]=size(w);
    M=wm*wn;
    w=zeros(1,M);
    wfd=zeros(1,M);
    wxw=zeros(1,M);
    num=size(s);
    num1=num(1);
    h= waitbar(0,'�������У������ĵȴ�������');
    
    for i=1:num1
        px=s(i).X;
        py=s(i).Y;
        n1=size(px);
        n2=n1(2)-1;
        pxx=px(1:n2);
        pyy=py(1:n2);
        
        n3=size(pxx);
        npoint=n3(2);
        
        %         ����ʼ
        r=100;%��������ֵ
        sctrl=1e5*just;
        for j=1:npoint
            dx=floor(pxx(j));
            dy=floor(pyy(j));
            if isnan(dx)
                continue
            end
            indexX=mod(dx,M)+1;
            indexY=mod(dy,M)+1;
            fx=pxx(j)*sctrl;
            fy=pyy(j)*sctrl;
            if mod(fx,r)<=r/2
                w(indexX)=w(indexX)-1;
            else
                w(indexX)=w(indexX)+1;
            end
            if mod(fy,r)<=r/2
                w(indexY)= w(indexY)-1;
            else
                w(indexY)= w(indexY)+1;
            end
        end
        %    �������
        %    FFT��ʼ
        fctrl=1e8*just;
        z=pxx+pyy*1i;
        y=fft(z);
        fd=abs(y);
        xw=angle(y);
        fd=fd*fctrl;
        xw=xw*fctrl;
        p=mod(floor(fd(2)/100),M)+1;
        if isnan(p)
            continue
        end
        pxw=mod(floor(xw(2)/100),M)+1;
        for  n=2:npoint
            if mod(fd(n),R)<=R/2
                wfd(p)=wfd(p)-1;
            else
                wfd(p)=wfd(p)+1;
            end
            if mod(xw(n),R)<=R/2
                wxw(pxw)=wxw(pxw)-1;
            else
                wxw(pxw)=wxw(pxw)+1;
            end
            p=p+1;
            if p==M+1
                p=1;
            end
            pxw=pxw+1;
            if pxw==M+1
                pxw=1;
            end
        end
        %    fft����
        
        waitbar(i/num1);
    end
    for i=1:M
        if w(i)>=0
            w(i)=1;
        else
            w(i)=0;
        end
        if wfd(i)>=0
            wfd(i)=1;
        else
            wfd(i)=0;
        end
        if wxw(i)>=0
            wxw(i)=1;
        else
            wxw(i)=0;
        end
    end
    
    w=logical(w);
    w=logisticD(w,0.98);
    w=reshape(w,wm,wn);
    imwrite(w,cmap,[pathname filename 'wSpace.bmp']);
    
    wfd=logical(wfd);
    wfd=logisticD(wfd,0.98);
    wfd=reshape(wfd,wm,wn);
    imwrite(wfd,cmap,[pathname filename 'wfd.bmp']);
    
    wxw=logical(wxw);
    wxw=logisticD(wxw,0.98);
    wxw=reshape(wxw,wm,wn);
    imwrite(wxw,cmap,[pathname filename 'wxw.bmp']);
    close(h);
end
msgbox('���');
